# Task API — Java + AWS Lambda

A minimal serverless REST API for managing a task list, built in Java and
deployed on AWS Lambda + API Gateway.

## Tech Stack
- Java 17
- AWS Lambda (compute)
- Amazon API Gateway (HTTP routing)
- Maven (build)
- Jackson (JSON serialization)

## Endpoints
| Method | Path    | Description                          |
|--------|---------|---------------------------------------|
| GET    | /tasks  | Returns all tasks as JSON             |
| POST   | /tasks  | Creates a task. Body: `{"title": "..."}` |

## Project Structure
```
task-api-project/
├── pom.xml
├── README.md
└── src/main/java/com/pratik/taskapi/
    ├── Task.java          # Task model
    └── TaskHandler.java   # Lambda entry point (handleRequest)
```

## How to Build
Requires JDK 17+ and Maven installed.

```bash
mvn clean package
```

This produces `target/task-api.jar` — a single "fat" JAR with all
dependencies bundled in. This is the file you upload to Lambda.

## How to Deploy (AWS Console)

1. **Create the Lambda function**
   - AWS Console → Lambda → Create function → Author from scratch
   - Runtime: Java 17
   - Upload `target/task-api.jar`
   - Handler: `com.pratik.taskapi.TaskHandler::handleRequest`

2. **Test it directly in Lambda first**
   - Use the "Test" tab with a sample API Gateway proxy event
   - Confirm you get a 200 response with the seeded task

3. **Connect API Gateway**
   - API Gateway → Create API → HTTP API
   - Add route: `GET /tasks` → integrate with your Lambda function
   - Add route: `POST /tasks` → integrate with your Lambda function
   - Deploy the API — AWS gives you a public invoke URL

4. **Test the live API**
   ```bash
   curl https://YOUR-API-ID.execute-api.REGION.amazonaws.com/tasks

   curl -X POST https://YOUR-API-ID.execute-api.REGION.amazonaws.com/tasks \
     -H "Content-Type: application/json" \
     -d '{"title": "Learn AWS Lambda"}'
   ```

## Notes
- Tasks are stored in-memory, so the list resets on a Lambda cold start.
  This keeps the project simple; swapping in DynamoDB would be a natural
  next step to persist data.
- Built as a learning project to gain hands-on experience with Java on
  AWS Lambda and API Gateway.

## Author
Pratik Kumar Sahoo
