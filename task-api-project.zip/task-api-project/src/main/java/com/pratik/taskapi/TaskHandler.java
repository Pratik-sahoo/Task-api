package com.pratik.taskapi;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Entry point AWS Lambda calls for every API request.
 *
 * Routes handled:
 *   GET  /tasks       -> list all tasks
 *   POST /tasks       -> create a new task (body: {"title": "Buy milk"})
 *
 * Lambda handler setting in the AWS Console should be:
 *   com.pratik.taskapi.TaskHandler::handleRequest
 */
public class TaskHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {

    // In-memory "database" - resets whenever Lambda cold-starts.
    // Good enough for a demo project; swap for DynamoDB later if you want to extend this.
    private static final List<Task> TASKS = new ArrayList<>();
    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        // seed with one example task so GET /tasks returns something immediately
        TASKS.add(new Task(NEXT_ID.getAndIncrement(), "Deploy my first Lambda function", true));
    }

    @Override
    public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent request, Context context) {
        String method = request.getHttpMethod();
        String path = request.getPath();

        context.getLogger().log("Received " + method + " " + path);

        try {
            if ("GET".equalsIgnoreCase(method)) {
                return respond(200, MAPPER.writeValueAsString(TASKS));
            }

            if ("POST".equalsIgnoreCase(method)) {
                Map<String, Object> body = MAPPER.readValue(
                        request.getBody() == null ? "{}" : request.getBody(),
                        Map.class
                );
                String title = (String) body.getOrDefault("title", "Untitled task");

                Task newTask = new Task(NEXT_ID.getAndIncrement(), title, false);
                TASKS.add(newTask);

                return respond(201, MAPPER.writeValueAsString(newTask));
            }

            return respond(405, "{\"error\":\"Method not allowed\"}");

        } catch (Exception e) {
            context.getLogger().log("Error handling request: " + e.getMessage());
            return respond(500, "{\"error\":\"Internal server error\"}");
        }
    }

    private APIGatewayProxyResponseEvent respond(int statusCode, String body) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        // Allows you to test this from a browser-based tool without CORS issues
        headers.put("Access-Control-Allow-Origin", "*");

        return new APIGatewayProxyResponseEvent()
                .withStatusCode(statusCode)
                .withHeaders(headers)
                .withBody(body);
    }
}
