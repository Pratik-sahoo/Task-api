package com.pratik.taskapi;

/**
 * A simple Task model.
 * In a real app this would live in a database - here we keep it
 * in-memory to keep the project small and easy to finish.
 */
public class Task {

    private int id;
    private String title;
    private boolean done;

    public Task() {
        // Needed by Jackson for JSON deserialization
    }

    public Task(int id, String title, boolean done) {
        this.id = id;
        this.title = title;
        this.done = done;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
